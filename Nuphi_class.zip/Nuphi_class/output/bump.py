import numpy as np
import matplotlib.pyplot as plt
import math

# load data from class out files of transfer functions 
z1,H1,I1,J1,K1,L1,M1= np.loadtxt("explanatory07_background.dat", unpack=True,usecols = [0,15,9,10,11,12,8])
cz1,cH1,cI1,cJ1,cK1,cL1,cM1= np.loadtxt("explanatory08_background.dat", unpack=True,usecols = [0,15,9,10,11,12,8])
R1=I1/H1
R2=J1/H1
R3=K1/H1
R4=L1/H1
R5=M1/H1
cR1=cI1/cH1
cR2=cJ1/cH1
cR3=cK1/cH1
cR4=cL1/cH1
cR5=cM1/cH1
#plt.semilogx(z1,R1,label='baryon')
plt.semilogx(z1,R2,label='cdm')
#plt.semilogx(z1,R3,label='Lambda')
plt.semilogx(z1,R4,label='Nuphi')
#plt.semilogx(z1,R5,label='Ur')
#plt.semilogx(cz1,cR1,label='baryon')
plt.semilogx(cz1,cR2,label='cdm')
#plt.semilogx(cz1,cR3,label='Lambda')
plt.semilogx(cz1,cR4,label='Nuphi')
#plt.semilogx(cz1,cR5,label='Ur')
plt.xlim(0,50000)
plt.ylabel(r"$\frac{\rho}{\rho_c}$")
plt.xlabel(r"(z)")
plt.legend()
plt.show()
